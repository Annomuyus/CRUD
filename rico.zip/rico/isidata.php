<?php
include "koneksi.php";

if(isset($_POST['submit'])){
  $nama = $_POST['nama'];
  $nim = $_POST['nim'];
  $prodi = $_POST['prodi'];
  $email = $_POST['email'];
  $password = $_POST['password'];
  $jenis = $_POST['jenis'];
  $tanggal = $_POST['tanggal'];
  $alamat = $_POST['alamat'];


  if ($nama && $nim && $prodi && $email && $password && $jenis && $tanggal && $alamat) {
    $sql1 = "insert into datarico 
    (nama, nim, prodi, email, password, jenis, tanggal, alamat) values ('$nama','$nim','$prodi','$email','$password','$jenis','$tanggal','$alamat')";
    $q1 = mysqli_query($koneksi,$sql1);
  
  } 
  
echo "data dimasukkan";
}

?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" href="style2.css">
    <title>Web Form</title>
  </head>
  <body>

    <div class="sidebar">
        <nav>
          <ul>
            <li><a href="index.html">Home</a></li>
            <li><a href="isidata.php">Form</a></li>
            <li><a href="tabel.php">Data</a></li>
          </ul>
        </nav>
      </div>

    <header>
        <h1>PT. RICO BEKERJA</h1>
      </header>

    

    <h1>ISI DATA BARU</h1>

<div class="kotak_login">


  <form action="" method="post"> 
  <div class="container">
    <label for="email"><b>Nama</b></label>
    <input class="form_login" type="text" name="nama" id="nama" required>

    <label for="psw"><b>NIM</b></label>
    <input class="form_login" type="text" name="nim" id="nim" required>

    <label for="psw-repeat"><b>Prodi</b></label>
    <input class="form_login" type="text" name="prodi" id="prodi" required>

    <label for="psw"><b>Email</b></label>
    <input class="form_login" type="email" name="email" id="email" required>

    <label for="psw"><b>Password</b></label>
    <input class="form_login" type="text" name="password" id="password" required>

    <label for="psw"><b>Jenis Kelamin</b></label>
    <input class="form_login" type="text" name="jenis" id="jenis" required>

    <label for="psw"><b>Tanggal Lahir</b></label>
    <input class="form_login" type="text" name="tanggal" id="tanggal" required>

    <label for="psw"><b>Alamat</b></label>
    <input class="form_login" type="text" name="alamat" id="alamat" required>

    
      <button type="submit" name="submit" id="submit">KIRIM</button>
  </div>
</form>

</div>


<div class="footer">
    <footer>
        <p>Copyright 2023. RICO</p>
      </footer>
      </div>
  </body>
</html>