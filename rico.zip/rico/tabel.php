<?php
include "koneksi.php";

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style3.css">
    <title>Web Data</title>
</head>
<body>

    <header>
        <h1>PT. RICO SUKA RPL</h1>
      </header>

    


    <table>
        <thead>
            <tr>
                <th>Name</th>
                <th>NIM</th>
                <th>Jurusan</th>
                <th>Email</th>
                <th>Password</th>
                <th>Jenis Kelamin</th>
                <th>Tanggal Lahir</th>
                <th>Alamat</th>
            </tr>
        </thead>
        <tbody>
            <?php
          $sql2 = "select * from datarico order by 'id' desc ";
          $q2 = mysqli_query($koneksi,$sql2);
          while($r2 = mysqli_fetch_array ($q2)){
            $nama = $r2['nama'];
            $nim = $r2['nim'];
            $prodi = $r2['prodi'];
            $email = $r2['email'];
            $password = $r2['password'];
            $jenis = $r2['jenis'];
            $lahir = $r2['tanggal'];
            $alamat = $r2['alamat'];
          ?>
          <tr>
           <th scope="row"> <?php echo $nama ?> </th>
           <th scope="row"> <?php echo $nim ?> </th>
           <th scope="row"> <?php echo $prodi ?> </th>
           <th scope="row"> <?php echo $email ?> </th>
           <th scope="row"> <?php echo $password ?> </th>
           <th scope="row"> <?php echo $jenis ?> </th>
           <th scope="row"> <?php echo $lahir ?> </th>
           <th scope="row"> <?php echo $alamat ?> </th>
          </tr>
          <?php
          }
          ?>
            
        </tbody>
    </table>


        <footer>
            <p>Copyright 2023. RICO</p>
          </footer>
</body>

</html>
